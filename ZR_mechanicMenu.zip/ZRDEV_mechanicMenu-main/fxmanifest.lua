fx_version 'adamant'

game 'gta5'
lua54 'yes'

version '1.0'
shared_script '@ox_lib/init.lua'


client_scripts {
    'client.lua',
}

server_scripts {
    "server.lua"
}
