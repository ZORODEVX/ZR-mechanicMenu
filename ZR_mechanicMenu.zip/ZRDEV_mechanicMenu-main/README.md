![img001](https://github.com/fabryyzzz/fdsdev_mechanicMenu/assets/58892804/bdcdda2a-429b-4f18-93b0-fef368f85219)

# discord.gg/amEJNfn9HX - FDS Development Discord for Support
# Mechanic Menu - esx_lscustom Remake with ox_lib menus
Inspired to vMenu, this menu will show just available modifies for the vehicle that we are using
